from fastapi import FastAPI
import schemas
from fastapi import Body
import models
from database import Base, engine, SessionLocal
from sqlalchemy.orm import Session

#main.py
from fastapi import FastAPI,Body, Depends
import schemas
import models
from database import Base, engine, SessionLocal
from sqlalchemy.orm import Session
#This will create our database if it doesent already exists
Base.metadata.create_all(engine)
def get_session():
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


app = FastAPI()

fakeDatabase ={
    1:{'name':'ajay'},
    2:{'Age':'22'},
    3:{'Gender':'male'}
}

#==================================================
# working with normal fake data
# @app.get('/{id}')
# def index(id:int):
#     # return "this is my Custom Code "
#     return fakeDatabase[id]


# @app.post('/')
# def post_data(department:str):
#     keys = len(fakeDatabase.keys())+1
#     fakeDatabase[keys]={'dc':department}
#     return fakeDatabase



#==================================================


#working with py pydantic
# @app.post('/')
# def addItem(item:schemas.Item):
#     newid =len(fakeDatabase.keys())+1
#     fakeDatabase[newid] ={'task':item.task}
#     return fakeDatabase

# @app.get('/')
# def getData():
#     return fakeDatabase


# @app.post("/")
# def addItem(body = Body()):
#    newId = len(fakeDatabase.keys()) + 1
#    fakeDatabase[newId] = {"task":body['task']}
#    return fakeDatabase


# @app.put("/{id}")
# def updateItem(id:int, item:schemas.Item):
#     fakeDatabase[id]['task'] = item.task 
#     return fakeDatabase

# @app.delete("/{id}")
# def deleteItem(id:int):
#     del fakeDatabase[id]
#     return fakeDatabase



@app.get("/")
def getItems(session: Session = Depends(get_session)):
    items = session.query(models.Item).all()
    return items

@app.post("/")
def addItem(item:schemas.Item):
    with Session(engine) as session:
        item = models.Item(task = item.task)
        session.add(item)
        session.commit()
        session.refresh(item)
        return item

@app.get("/{id}")
def getItem(id:int, session: Session = Depends(get_session)):
    item = session.query(models.Item).get(id)
    return item




@app.put("/{id}")
def updateItem(id:int, item:schemas.Item, session = Depends(get_session)):
    itemObject = session.query(models.Item).get(id)
    itemObject.task = item.task
    session.commit()
    return itemObject


@app.delete("/{id}")
def deleteItem(id:int, session = Depends(get_session)):
    itemObject = session.query(models.Item).get(id)
    session.delete(itemObject)
    session.commit()
    session.close()
    return 'Item was deleted'